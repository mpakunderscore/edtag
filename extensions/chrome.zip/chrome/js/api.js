var host = "https://edtag.io";
//var host = "http://localhost:9000";

var notificationTime = 2000;

function setDomains() {

    var url = host + "/domains";

    var request = new XMLHttpRequest();
    request.open( "GET", url, false );
    request.send( null );

    var domains = request.responseText;
    localStorage.setItem("domains", domains);
}

function add_url(tab) {

    if (tab.status != "complete") return;

    var url = host + "/add?url=" + encodeURIComponent(tab.url);

    var request = new XMLHttpRequest();
    request.open( "GET", url, false );
    request.send( null );

    var response = request.responseText;

    if (response.length == 0) return; //TODO

    var webData = JSON.parse(response);

    console.log(tab.url.split("://")[1].replace("www.", ""));

    notification(tab["favIconUrl"], webData.title.replace(" - Wikipedia, the free encyclopedia", ""), sort(JSON.parse(webData.tags)).join(", ")); //TODO
}

function notification(favIcon, title, text) {

    var notification = window.webkitNotifications.createNotification(
        favIcon,    // The image.
        title,      // The title.
        text        // The body.
    );

    notification.show();

    setTimeout( function() { notification.cancel() }, notificationTime );
}

function sort(tags) {

    var sortable = [];
    var sorted_tags = [];

    for (var tag in tags)
        if (tags[tag] != null)
            sortable.push([tag, tags[tag]]);

    sortable.sort(function(b, a) {return a[1] - b[1]});

    for(var key in sortable) {
        sorted_tags.push(sortable[key][0]);
    }

    return sorted_tags;
}